using System.Data;
using System.Linq.Expressions;

namespace WinForms_Calculator
{
    public partial class Form1 : Form
    {
        private Button[] numberButtons = new Button[10];
        private Button[] operationButtons = new Button[4];
        private Button buttonClear;
        private Button buttonEqual;
        private Button buttonCom;
        public Form1()
        {
            InitializeComponent();
            InitializeButtons();
        }

        private void InitializeButtons()
        {
            int buttonWidth = 50;
            int buttonHeight = 50;
            int xOffset = 10;
            int yOffset = 60;

            // �����
            for (int i = 0; i < 10; i++)
            {
                numberButtons[i] = new Button();
                numberButtons[i].Name = "button" + i;
                numberButtons[i].Text = i.ToString();
                numberButtons[i].Size = new System.Drawing.Size(buttonWidth, buttonHeight);
                numberButtons[i].Location = new System.Drawing.Point(xOffset + (i % 3) * (buttonWidth + 10), yOffset + (i / 3) * (buttonHeight + 10));
                numberButtons[i].TabIndex = i;
                numberButtons[i].Click += new EventHandler(NumberButton_Click);
                this.Controls.Add(numberButtons[i]);
            }

            // ������ Clear
            buttonClear = new Button();
            buttonClear.Name = "buttonClear";
            buttonClear.Text = "C";
            buttonClear.Size = new System.Drawing.Size(buttonWidth, buttonHeight);
            buttonClear.Location = new System.Drawing.Point(200, yOffset);
            buttonClear.TabIndex = 10;
            buttonClear.Click += new EventHandler(ClearButton_Click);
            this.Controls.Add(buttonClear);

            // ������ =
            buttonEqual = new Button();
            buttonEqual.Name = "buttonEqual";
            buttonEqual.Text = "=";
            buttonEqual.Size = new System.Drawing.Size(buttonWidth, buttonHeight);
            buttonEqual.Location = new System.Drawing.Point(200, yOffset + buttonHeight + 10); 
            buttonEqual.TabIndex = 11;
            buttonEqual.Click += new EventHandler(EqualButton_Click);
            this.Controls.Add(buttonEqual);

            // ������ .
            buttonCom = new Button();
            buttonCom.Name = "buttonCom";
            buttonCom.Text = ".";
            buttonCom.Size = new System.Drawing.Size(buttonWidth, buttonHeight);
            buttonCom.Location = new System.Drawing.Point(200, yOffset + buttonHeight + 70);
            buttonCom.TabIndex = 12;
            buttonCom.Click += new EventHandler(ComButton_Click);
            this.Controls.Add(buttonCom);

            // ����� ��
            string[] operations = { "+", "-", "*", "/" };
            for (int i = 0; i < 4; i++)
            {
                operationButtons[i] = new Button();
                operationButtons[i].Name = "buttonOp" + i;
                operationButtons[i].Text = operations[i];
                operationButtons[i].Size = new System.Drawing.Size(buttonWidth, buttonHeight);
                operationButtons[i].Location = new System.Drawing.Point(260, yOffset + i * (buttonHeight + 10));  // ���������� ������ ��������
                operationButtons[i].TabIndex = i + 12;
                operationButtons[i].Click += new EventHandler(OperationButton_Click);
                this.Controls.Add(operationButtons[i]);
            }
        }

        private void NumberButton_Click(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            string buttonText = clickedButton.Text;

            if (textBox1.Text == "0")
            {
                textBox1.Text = buttonText;
            }
            else
            {
                textBox1.Text += buttonText;
            }
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            textBox1.Text = "0";
        }

        private void EqualButton_Click(object sender, EventArgs e)
        {
            try
            {
                var result = new System.Data.DataTable().Compute(textBox1.Text, null);
                textBox1.Text = result.ToString();
            }
            catch
            {
                textBox1.Text = "Error";
            }
        }

        private void OperationButton_Click(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            string buttonText = clickedButton.Text;

            if (textBox1.Text != "0")
            {
                textBox1.Text += " " + buttonText + " ";
            }
        }

        private void ComButton_Click(object sender, EventArgs e) 
        {
            Button clickedButton = (Button)sender;
            string buttonText = clickedButton.Text;

            if (textBox1.Text != "0") 
            {
                textBox1.Text += buttonText;
            }
        }
    }
}